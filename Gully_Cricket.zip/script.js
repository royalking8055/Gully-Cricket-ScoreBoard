/* ============================================================
   GULLY CRICKET SCORECARD
   script.js — All game logic, history, and theme toggle
   Scorecard For Future Best Players
   ============================================================ */

// ══════════════════════════════════════════════
//  STATE
// ══════════════════════════════════════════════
let cfg = {};
let state = {};

// ══════════════════════════════════════════════
//  SETUP
// ══════════════════════════════════════════════
function buildPlayerInputs() {
  const maxP = 11;
  for (let t = 1; t <= 2; t++) {
    const wrap = document.getElementById(`t${t}-players`);
    wrap.innerHTML = '';
    for (let i = 1; i <= maxP; i++) {
      const color = t === 1 ? '#58a6ff' : '#f85149';
      wrap.innerHTML += `
        <div class="player-input-wrap">
          <span class="player-num">${i}</span>
          <input id="t${t}p${i}" type="text" placeholder="Player ${i}" maxlength="16">
        </div>`;
    }
  }
}

buildPlayerInputs();

function getPlayers(t) {
  const arr = [];
  for (let i = 1; i <= 11; i++) {
    const v = document.getElementById(`t${t}p${i}`).value.trim();
    if (v) arr.push(v);
  }
  return arr;
}

function startMatch() {
  const t1Name = document.getElementById('t1-name').value.trim() || 'Team Alpha';
  const t2Name = document.getElementById('t2-name').value.trim() || 'Team Beta';
  const t1Players = getPlayers(1);
  const t2Players = getPlayers(2);
  const overs = parseInt(document.getElementById('setup-overs').value);
  const maxWickets = parseInt(document.getElementById('setup-wickets').value);

  if (t1Players.length < 2 || t2Players.length < 2) {
    alert('Please add at least 2 players per team!');
    return;
  }

  cfg = { overs, maxWickets };
  initState(t1Name, t1Players, t2Name, t2Players);
  showScreen('screen-game');
  renderGame();
  openBowlerModal();
}

function initState(t1Name, t1Players, t2Name, t2Players) {
  state = {
    teams: [
      { name: t1Name, players: t1Players.map(n => ({ name: n, runs: 0, balls: 0, fours: 0, sixes: 0, out: false, didBat: false })), score: 0, wickets: 0, balls: 0, extras: 0 },
      { name: t2Name, players: t2Players.map(n => ({ name: n, runs: 0, balls: 0, fours: 0, sixes: 0, out: false, didBat: false })), score: 0, wickets: 0, balls: 0, extras: 0 }
    ],
    bowlers: [
      t2Players.map(n => ({ name: n, overs: 0, balls: 0, runs: 0, wickets: 0 })),
      t1Players.map(n => ({ name: n, overs: 0, balls: 0, runs: 0, wickets: 0 }))
    ],
    inning: 0, // 0 = 1st, 1 = 2nd
    striker: 0,
    nonStriker: 1,
    playerIdx: 2, // next player to come in
    bowlerIdx: -1,
    currentOverBalls: [],
    completedOvers: [],
    history: [], // for undo
    innings1Complete: false,
  };
  state.teams[0].players[0].didBat = true;
  state.teams[0].players[1].didBat = true;
}

// ══════════════════════════════════════════════
//  SCREEN
// ══════════════════════════════════════════════
function showScreen(id) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  document.getElementById(id).classList.add('active');
}

// ══════════════════════════════════════════════
//  SCORING
// ══════════════════════════════════════════════
function currentTeam() { return state.teams[state.inning]; }
function bowlingTeam() { return state.teams[1 - state.inning]; }
function currentBowler() { return state.bowlers[state.inning][state.bowlerIdx]; }

function legalBallCount() {
  return state.currentOverBalls.filter(b => b.type !== 'wd' && b.type !== 'nb').length;
}

function scoreRun(r) {
  if (state.bowlerIdx < 0) return;
  const ball = { type: 'run', runs: r, striker: state.striker };
  pushBall(ball);

  const team = currentTeam();
  const batter = team.players[state.striker];
  team.score += r;
  batter.runs += r;
  batter.balls++;
  team.balls++;
  if (r === 4) batter.fours++;
  if (r === 6) batter.sixes++;
  currentBowler().runs += r;
  currentBowler().balls++;

  if (r % 2 === 1) swapStrike(); // odd runs = swap
  checkOverEnd();
}

function scoreExtra(type) {
  if (state.bowlerIdx < 0) return;
  if (type === 'bye') { openModal('modal-bye'); return; }

  const ball = { type, runs: 1 };
  pushBall(ball);
  const team = currentTeam();
  team.score += 1;
  team.extras += 1;
  currentBowler().runs += 1;
  // wide and noball don't count as a ball
  renderGame();
}

function confirmBye(r) {
  closeModal('modal-bye');
  const ball = { type: 'bye', runs: r };
  pushBall(ball);
  const team = currentTeam();
  const batter = team.players[state.striker];
  team.score += r;
  team.extras += r;
  batter.balls++;
  team.balls++;
  currentBowler().balls++;
  if (r % 2 === 1) swapStrike();
  checkOverEnd();
}

function scoreWicket() {
  if (state.bowlerIdx < 0) return;
  const ball = { type: 'wkt', runs: 0, striker: state.striker };
  pushBall(ball);

  const team = currentTeam();
  const batter = team.players[state.striker];
  batter.out = true;
  batter.balls++;
  team.balls++;
  team.wickets++;
  currentBowler().balls++;
  currentBowler().wickets++;

  const maxW = Math.min(cfg.maxWickets, team.players.length - 1);
  if (team.wickets >= maxW || checkAllOut(team)) {
    endInnings();
    return;
  }

  // Bring in next batter
  openBatsmanModal();
  checkOverEnd(true); // check over but don't auto-open bowler yet
}

function checkAllOut(team) {
  const maxW = Math.min(cfg.maxWickets, team.players.length - 1);
  return team.wickets >= maxW;
}

function swapStrike() {
  [state.striker, state.nonStriker] = [state.nonStriker, state.striker];
}

function checkOverEnd(afterWicket = false) {
  if (legalBallCount() >= 6) {
    // Over complete
    const overRuns = state.currentOverBalls.reduce((s, b) => s + b.runs, 0);
    currentBowler().overs++;
    currentBowler().balls = 0;

    state.completedOvers.push({
      num: state.completedOvers.length + 1,
      runs: overRuns,
      balls: [...state.currentOverBalls],
      bowler: currentBowler().name
    });
    state.currentOverBalls = [];
    swapStrike(); // end of over swap

    const totalOvers = state.completedOvers.length;
    if (totalOvers >= cfg.overs) {
      endInnings();
      return;
    }

    if (!afterWicket) openBowlerModal();
  }

  checkChaseWin();
  renderGame();
}

function checkChaseWin() {
  if (state.inning === 1) {
    const target = state.teams[0].score + 1;
    if (state.teams[1].score >= target) {
      endInnings(true);
    }
  }
}

// ══════════════════════════════════════════════
//  INNINGS
// ══════════════════════════════════════════════
function endInnings(chaseWin = false) {
  if (state.inning === 0) {
    // Show break modal
    const t1 = state.teams[0];
    document.getElementById('break-title').textContent = `${t1.name}'s Innings Complete!`;
    document.getElementById('break-score').textContent = `Score: ${t1.score}/${t1.wickets} (${oversStr(t1.balls)} ov)`;
    document.getElementById('break-target').textContent = `Target for ${state.teams[1].name}: ${t1.score + 1} runs`;
    openModal('modal-break');
  } else {
    showResult(chaseWin);
  }
}

function startSecondInnings() {
  closeModal('modal-break');
  state.inning = 1;
  state.striker = 0;
  state.nonStriker = 1;
  state.playerIdx = 2;
  state.bowlerIdx = -1;
  state.currentOverBalls = [];
  state.completedOvers = [];

  const t2 = state.teams[1];
  t2.players[0].didBat = true;
  t2.players[1].didBat = true;

  renderGame();
  openBowlerModal();
}

// ══════════════════════════════════════════════
//  UNDO
// ══════════════════════════════════════════════
function pushBall(ball) {
  // Save snapshot
  state.history.push(JSON.parse(JSON.stringify({ ...state, history: [] })));
  state.currentOverBalls.push(ball);
}

function undoLastBall() {
  if (state.history.length === 0) return;
  const prev = state.history.pop();
  Object.assign(state, prev);
  state.history = state.history; // keep
  renderGame();
}

// ══════════════════════════════════════════════
//  MODALS
// ══════════════════════════════════════════════
function openModal(id) { document.getElementById(id).classList.add('open'); }
function closeModal(id) { document.getElementById(id).classList.remove('open'); }

function openBatsmanModal() {
  const team = currentTeam();
  const avail = team.players.filter((p, i) => !p.out && !p.didBat);
  const sel = document.getElementById('modal-batter-select');
  sel.innerHTML = avail.map(p => `<option>${p.name}</option>`).join('');
  if (avail.length === 0) { endInnings(); return; }
  openModal('modal-batsman');
}

function confirmBatsman() {
  closeModal('modal-batsman');
  const name = document.getElementById('modal-batter-select').value;
  const team = currentTeam();
  const idx = team.players.findIndex(p => p.name === name);
  team.players[idx].didBat = true;
  state.striker = idx;
  // If over just ended, also open bowler
  if (legalBallCount() === 0 && state.currentOverBalls.length === 0) {
    openBowlerModal();
  } else {
    renderGame();
  }
}

function openBowlerModal() {
  const bowlers = state.bowlers[state.inning];
  const sel = document.getElementById('modal-bowler-select');
  sel.innerHTML = bowlers.map((b, i) =>
    `<option value="${i}">${b.name} (${b.overs} ov, ${b.wickets}-${b.runs})</option>`
  ).join('');
  openModal('modal-bowler');
}

function confirmBowler() {
  closeModal('modal-bowler');
  state.bowlerIdx = parseInt(document.getElementById('modal-bowler-select').value);
  renderGame();
}

// ══════════════════════════════════════════════
//  RENDER
// ══════════════════════════════════════════════
function oversStr(balls) {
  return `${Math.floor(balls/6)}.${balls%6}`;
}

function rr(score, balls) {
  if (balls === 0) return '0.00';
  return ((score / balls) * 6).toFixed(2);
}

function renderGame() {
  const t1 = state.teams[0], t2 = state.teams[1];
  const batting = currentTeam();
  const inn = state.inning;

  // Match name
  document.getElementById('match-name-label').innerHTML =
    `<span>${t1.name}</span> vs <span>${t2.name}</span>`;

  // Panels
  document.getElementById('t1-panel-name').textContent = t1.name + (inn === 0 ? ' 🏏' : '');
  document.getElementById('t2-panel-name').textContent = t2.name + (inn === 1 ? ' 🏏' : '');

  document.getElementById('t1-score-display').textContent = `${t1.score}/${t1.wickets}`;
  document.getElementById('t1-overs-display').textContent = `${oversStr(t1.balls)} ov · RR: ${rr(t1.score, t1.balls)}`;

  if (inn === 0) {
    document.getElementById('t2-score-display').textContent = '—';
    document.getElementById('t2-overs-display').textContent = 'Yet to bat';
  } else {
    document.getElementById('t2-score-display').textContent = `${t2.score}/${t2.wickets}`;
    document.getElementById('t2-overs-display').textContent = `${oversStr(t2.balls)} ov · RR: ${rr(t2.score, t2.balls)}`;
  }

  document.getElementById('t1-panel').classList.toggle('batting-now', inn === 0);
  document.getElementById('t2-panel').classList.toggle('batting-now', inn === 1);

  document.getElementById('inning-badge').textContent = inn === 0 ? '1st Innings' : '2nd Innings';

  // Chase bar
  const chaseBar = document.getElementById('chase-bar');
  if (inn === 1) {
    chaseBar.classList.add('visible');
    const target = t1.score + 1;
    const need = target - t2.score;
    const ballsLeft = cfg.overs * 6 - t2.balls;
    const rrr = ballsLeft > 0 ? ((need / ballsLeft) * 6).toFixed(2) : '∞';
    document.getElementById('chase-need-text').textContent = `${need > 0 ? need : 0} runs from ${ballsLeft} balls`;
    document.getElementById('chase-rrr-text').textContent = rrr;
    document.getElementById('chase-balls-text').textContent = `Target: ${target}`;
    const pct = Math.min(100, (t2.score / t1.score) * 100);
    document.getElementById('chase-fill').style.width = pct + '%';
  } else {
    chaseBar.classList.remove('visible');
  }

  // Batters
  const s = state.striker, ns = state.nonStriker;
  const bps = batting.players;
  renderBatter('batter1', bps[s], true);
  if (bps[ns]) renderBatter('batter2', bps[ns], false);

  // Bowler
  if (state.bowlerIdx >= 0) {
    const bwlr = currentBowler();
    document.getElementById('bowler-name').textContent = bwlr.name;
    const bOvers = `${bwlr.overs}.${bwlr.balls}`;
    document.getElementById('bowler-eco').textContent = `${bOvers} ov · Econ: ${rr(bwlr.runs, bwlr.overs*6+bwlr.balls)}`;
    document.getElementById('bowler-figs').textContent = `${bwlr.wickets}-${bwlr.runs}`;
  }

  // This over balls
  document.getElementById('over-num-label').textContent = `Over ${state.completedOvers.length + 1}`;
  const br = document.getElementById('balls-row');
  br.innerHTML = '';
  const legalSoFar = legalBallCount();

  state.currentOverBalls.forEach(b => {
    const dot = document.createElement('div');
    dot.className = 'ball-dot';
    if (b.type === 'run') {
      dot.classList.add(`run-${Math.min(b.runs, 6)}`);
      dot.textContent = b.runs === 0 ? '·' : b.runs;
    } else if (b.type === 'wkt') {
      dot.classList.add('wicket');
      dot.textContent = 'W';
    } else if (b.type === 'wd') {
      dot.classList.add('wide');
      dot.textContent = 'WD';
    } else if (b.type === 'nb') {
      dot.classList.add('noball');
      dot.textContent = 'NB';
    } else if (b.type === 'bye') {
      dot.classList.add('wide');
      dot.textContent = `B${b.runs}`;
    }
    br.appendChild(dot);
  });

  // Remaining empty slots
  for (let i = legalSoFar; i < 6; i++) {
    const dot = document.createElement('div');
    dot.className = 'ball-dot empty';
    dot.textContent = '·';
    br.appendChild(dot);
  }

  // Batting scorecard sidebar
  renderScorecardSidebar();

  // Over pills
  const pills = document.getElementById('over-pills');
  pills.innerHTML = state.completedOvers.map(o =>
    `<div class="over-pill">Ov${o.num}: <span>${o.runs}</span></div>`
  ).join('');
}

function renderBatter(prefix, p, isStriker) {
  if (!p) return;
  const card = document.getElementById(`${prefix}-card`);
  card.classList.toggle('on-strike', isStriker);
  document.getElementById(`${prefix}-name`).textContent = (isStriker ? '🏏 ' : '') + p.name;
  document.getElementById(`${prefix}-score`).textContent = p.runs;
  document.getElementById(`${prefix}-balls`).textContent = `${p.balls} balls`;
  document.getElementById(`${prefix}-4s6s`).textContent = `${p.fours}×4 · ${p.sixes}×6`;
}

function renderScorecardSidebar() {
  const team = currentTeam();
  const tbody = document.getElementById('batting-scorecard-body');
  tbody.innerHTML = team.players.filter(p => p.didBat || p === team.players[state.striker] || p === team.players[state.nonStriker]).map(p => {
    const sr = p.balls > 0 ? ((p.runs / p.balls) * 100).toFixed(0) : '-';
    const isStriker = team.players[state.striker] === p;
    return `<tr>
      <td class="name-cell ${p.out ? 'out-name' : ''}">
        ${isStriker ? '<span class="on-strike-marker"></span>' : ''}${p.name.split(' ')[0]}
      </td>
      <td class="runs-td">${p.runs}</td>
      <td style="color:var(--muted)">${p.balls}</td>
      <td style="color:var(--accent)">${sr}</td>
    </tr>`;
  }).join('');
}

// ══════════════════════════════════════════════
//  RESULT
// ══════════════════════════════════════════════
function showResult(chaseWin = false) {
  const t1 = state.teams[0], t2 = state.teams[1];
  let winner, margin;

  if (state.inning === 0) {
    // Team 1 won (team 2 didn't bat or was bowled out)
    winner = t1.name;
    const maxW = Math.min(cfg.maxWickets, t2.players.length - 1);
    margin = `won (opponent didn't bat)`;
  } else {
    if (t2.score > t1.score) {
      const wktsLeft = Math.min(cfg.maxWickets, t2.players.length - 1) - t2.wickets;
      winner = t2.name;
      margin = `won by ${wktsLeft} wicket${wktsLeft !== 1 ? 's' : ''}`;
    } else if (t1.score > t2.score) {
      winner = t1.name;
      margin = `won by ${t1.score - t2.score} runs`;
    } else {
      winner = 'TIED MATCH';
      margin = 'What a game!';
    }
  }

  document.getElementById('result-winner').textContent = winner === 'TIED MATCH' ? '🤝 TIE!' : `${winner} WINS!`;
  document.getElementById('result-margin').textContent = winner === 'TIED MATCH' ? margin : `${winner} ${margin}`;

  document.getElementById('res-t1-name').textContent = t1.name;
  document.getElementById('res-t1-score').textContent = `${t1.score}/${t1.wickets}`;
  document.getElementById('res-t1-over').textContent = `${oversStr(t1.balls)} overs`;

  document.getElementById('res-t2-name').textContent = t2.name;
  document.getElementById('res-t2-score').textContent = `${t2.score}/${t2.wickets}`;
  document.getElementById('res-t2-over').textContent = `${oversStr(t2.balls)} overs`;

  // Top performers
  const allBatters = [...t1.players, ...t2.players].filter(p => p.balls > 0);
  const topBat = allBatters.sort((a,b) => b.runs - a.runs)[0];
  const topSix = allBatters.sort((a,b) => b.sixes - a.sixes)[0];
  const allBowlers = [...state.bowlers[0], ...state.bowlers[1]].filter(b => b.balls > 0);
  const topBowler = allBowlers.sort((a,b) => b.wickets - a.wickets || a.runs - b.runs)[0];

  const rows = [];
  if (topBat) rows.push({ label: '🏏 Top Scorer', name: topBat.name, val: `${topBat.runs} (${topBat.balls}b)` });
  if (topSix && topSix.sixes > 0) rows.push({ label: '💥 Most Sixes', name: topSix.name, val: `${topSix.sixes} sixes` });
  if (topBowler) rows.push({ label: '⚾ Best Bowler', name: topBowler.name, val: `${topBowler.wickets}/${topBowler.runs} (${topBowler.overs} ov)` });

  document.getElementById('perf-rows').innerHTML = rows.map(r => `
    <div class="perf-row">
      <div>
        <div class="perf-label">${r.label}</div>
        <div style="font-weight:700;font-size:14px">${r.name}</div>
      </div>
      <div class="perf-val">${r.val}</div>
    </div>
  `).join('');

  // Show date played on result screen
  const now = new Date();
  const dateStr = now.toLocaleDateString('en-IN', { weekday:'short', day:'numeric', month:'short', year:'numeric' });
  const timeStr = now.toLocaleTimeString('en-IN', { hour:'2-digit', minute:'2-digit' });
  document.getElementById('result-date-display').textContent = `${dateStr} · ${timeStr}`;

  // Determine result type for history
  let resultType = 'tie';
  if (winner !== 'TIED MATCH') {
    if (winner === t1.name) resultType = state.inning === 0 ? 'win' : 'win';
    else resultType = 'loss';
    // From t1's perspective
    resultType = winner === t1.name ? 'win' : 'loss';
  }

  // Save to history
  saveMatchToHistory({
    date: now.toISOString(),
    t1Name: t1.name,
    t2Name: t2.name,
    t1Score: t1.score,
    t1Wkts: t1.wickets,
    t1Overs: oversStr(t1.balls),
    t2Score: t2.score,
    t2Wkts: t2.wickets,
    t2Overs: oversStr(t2.balls),
    winner: winner === 'TIED MATCH' ? null : winner,
    margin,
    resultType,
    overs: cfg.overs,
    topBat:  topBat  ? { name: topBat.name,  runs: topBat.runs,  balls: topBat.balls }  : null,
    topBowl: topBowler ? { name: topBowler.name, wickets: topBowler.wickets, runs: topBowler.runs } : null,
    topSix:  topSix && topSix.sixes > 0 ? { name: topSix.name, sixes: topSix.sixes } : null,
  });

  showScreen('screen-result');
}

function playAgain() {
  showScreen('screen-setup');
}

// ══════════════════════════════════════════════
//  HISTORY — localStorage based
// ══════════════════════════════════════════════
const HIST_KEY = 'gully-cricket-history';

function loadHistory() {
  try { return JSON.parse(localStorage.getItem(HIST_KEY)) || []; }
  catch(e) { return []; }
}

function saveHistory(hist) {
  localStorage.setItem(HIST_KEY, JSON.stringify(hist));
}

function saveMatchToHistory(matchData) {
  const hist = loadHistory();
  hist.unshift(matchData); // newest first
  if (hist.length > 50) hist.pop(); // cap at 50 matches
  saveHistory(hist);
}

function clearAllHistory() {
  if (!confirm('Clear all match history? This cannot be undone.')) return;
  localStorage.removeItem(HIST_KEY);
  renderHistoryScreen();
}

function deleteHistoryEntry(idx) {
  const hist = loadHistory();
  hist.splice(idx, 1);
  saveHistory(hist);
  renderHistoryScreen();
}

function viewHistory() {
  renderHistoryScreen();
  showScreen('screen-history');
}

function formatDate(iso) {
  const d = new Date(iso);
  return d.toLocaleDateString('en-IN', { day:'numeric', month:'short', year:'numeric', hour:'2-digit', minute:'2-digit' });
}

function renderHistoryScreen() {
  const hist = loadHistory();
  const wrap = document.getElementById('history-list-wrap');

  // Stats bar
  const played = hist.length;
  const wins   = hist.filter(m => m.resultType === 'win').length;
  const losses = hist.filter(m => m.resultType === 'loss').length;
  const ties   = hist.filter(m => m.resultType === 'tie').length;
  document.getElementById('hs-played').textContent = played;
  document.getElementById('hs-wins').textContent   = wins;
  document.getElementById('hs-losses').textContent = losses;
  document.getElementById('hs-ties').textContent   = ties;

  if (!played) {
    wrap.innerHTML = `<div class="no-history"><div class="no-hist-icon">🏏</div><div>No matches played yet.</div><div style="font-size:13px;margin-top:6px;color:var(--muted2)">Play your first match and it will appear here!</div></div>`;
    return;
  }

  wrap.innerHTML = `<div class="match-history-list">${hist.map((m, i) => buildMatchCard(m, i)).join('')}</div>`;
}

function buildMatchCard(m, idx) {
  const badgeClass = m.resultType === 'tie' ? 'tie' : 'win';
  const badgeText  = m.resultType === 'tie' ? '🤝 TIE' : `🏆 ${escHtml(m.winner)} WON`;
  const margin     = m.resultType === 'tie' ? 'Match tied' : escHtml(m.margin);

  return `
  <div class="match-history-card" style="animation-delay:${idx*0.05}s">
    <div class="mhc-top">
      <div class="mhc-teams">
        <span class="t1c">${escHtml(m.t1Name)}</span>
        <span class="vsep">vs</span>
        <span class="t2c">${escHtml(m.t2Name)}</span>
      </div>
      <div style="display:flex;align-items:center;gap:8px">
        <div class="mhc-winner-badge ${badgeClass}">${badgeText}</div>
        <button class="mhc-delete" onclick="deleteHistoryEntry(${idx})" title="Delete">✕</button>
      </div>
    </div>
    <div class="mhc-scores">
      <div class="mhc-score-cell">
        <div class="mhc-score-team">${escHtml(m.t1Name)}</div>
        <div class="mhc-score-val batting">${m.t1Score}/${m.t1Wkts}</div>
        <div class="mhc-score-ov">${m.t1Overs} overs</div>
      </div>
      <div class="mhc-score-cell">
        <div class="mhc-score-team">${escHtml(m.t2Name)}</div>
        <div class="mhc-score-val bowling">${m.t2Score}/${m.t2Wkts}</div>
        <div class="mhc-score-ov">${m.t2Overs} overs</div>
      </div>
    </div>
    <div class="mhc-meta">
      <div class="mhc-performers">
        ${m.topBat  ? `<div class="mhc-perf-item"><span class="mhc-perf-lbl">🏏</span><span class="mhc-perf-val">${escHtml(m.topBat.name)} ${m.topBat.runs}(${m.topBat.balls}b)</span></div>` : ''}
        ${m.topBowl ? `<div class="mhc-perf-item"><span class="mhc-perf-lbl">⚾</span><span class="mhc-perf-val">${escHtml(m.topBowl.name)} ${m.topBowl.wickets}/${m.topBowl.runs}</span></div>` : ''}
        ${m.topSix && m.topSix.sixes > 0 ? `<div class="mhc-perf-item"><span class="mhc-perf-lbl">💥</span><span class="mhc-perf-val">${escHtml(m.topSix.name)} ${m.topSix.sixes}×6</span></div>` : ''}
      </div>
      <div class="date-chip">📅 ${formatDate(m.date)}</div>
    </div>
  </div>`;
}

function escHtml(str) {
  return String(str).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}


// ══════════════════════════════════════════════
//  THEME TOGGLE
// ══════════════════════════════════════════════
function toggleTheme() {
  const isLight = document.body.classList.toggle('light');
  document.getElementById('theme-icon').textContent = isLight ? '☀️' : '🌙';
  document.getElementById('theme-label').textContent = isLight ? 'Light' : 'Dark';
  localStorage.setItem('cricket-theme', isLight ? 'light' : 'dark');
}

// Load saved theme on startup
(function() {
  const saved = localStorage.getItem('cricket-theme');
  if (saved === 'light') {
    document.body.classList.add('light');
    document.addEventListener('DOMContentLoaded', () => {
      const icon = document.getElementById('theme-icon');
      const lbl = document.getElementById('theme-label');
      if (icon) icon.textContent = '☀️';
      if (lbl) lbl.textContent = 'Light';
    });
  }
})();